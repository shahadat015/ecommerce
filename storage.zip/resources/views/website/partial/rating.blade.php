<ul>
	<li><i class="{{ rating_star_class($rating, 1) }}"></i></li>
	<li><i class="{{ rating_star_class($rating, 2) }}"></i></li>
	<li><i class="{{ rating_star_class($rating, 3) }}"></i></li>
	<li><i class="{{ rating_star_class($rating, 4) }}"></i></li>
	<li><i class="{{ rating_star_class($rating, 5) }}"></i></li>
</ul>