<?php if(Cart::count()): ?>
    <div class="col-xl-12">
        <div class="cart_main_content">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">Remove</th>
                        <th scope="col">Image</th>
                        <th scope="col">Product(s) </th>
                        <th scope="col">Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- single add to cart item-->
                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr scope="row">
                        <td class="remove_btn_cart">
                            <a class="removefromcart" href="<?php echo e(route('cart.remove', $cartItem->rowId)); ?>"><i class="icofont-trash"></i></a>
                        </td>
                        <td class="text-center">
                            <img width="80" class="img-fluid" src="<?php echo e(asset($cartItem->options->image)); ?>" alt=""></td>
                        <td>
                            <h4><?php echo e($cartItem->name); ?></h4>
                            <?php $__currentLoopData = $cartItem->options->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($option->name); ?>:  <?php echo e($option->values->implode('label', ', ')); ?></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="add_cart_price text-center">&#2547; <?php echo e($cartItem->price); ?></td>
                        <td>
                            <div class="quantity_form_input btn-qty">
                                <input data-rowid="<?php echo e($cartItem->rowId); ?>" type="number" value="<?php echo e($cartItem->qty); ?>" min="1" max="100" step="1"> 
                            </div>
                        </td>
                        <td class="add_cart_price_total text-center">&#2547; <?php echo e($cartItem->total); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-xl-12">
        <div class="cart_sumary">
            <div class="row">
                <div class="col-xl-7 col-lg-7 col-md-6">
                    <div class="cart_sum_btn"> <a href="<?php echo e(route('cart')); ?>">Update Cart</a> <a class="btn_cart_sum_sp" href="<?php echo e(url('/')); ?>"><i class="icofont-shopping-cart"></i> Continue Shoping</a> </div>
                    <div class="copon_apply_form">
                        <input type="text" placeholder="Coupe Code">
                        <button type="submit">Apply Code</button>
                    </div>
                </div>
                <div class="col-xl-5 col-lg-5 col-md-6">
                    <div class="cart_sum_content">
                        <ul>
                            <?php
                                $freeShippingEnabled = config('settings.free_shipping_enabled');
                                $freeShippingMinAmount = config('settings.free_shipping_min_amount');
                                $localPicupEnabled = config('settings.local_pickup_enabled');
                                $localPicupCost = config('settings.local_pickup_cost');
                                $freeshippingAble = $freeShippingMinAmount < Cart::subtotal();
                                $cartTotal = $freeshippingAble ? Cart::total() : Cart::total() + $localPicupCost;
                            ?>
                            <li>Sub-Total:<span>Tk <?php echo e(Cart::subtotal()); ?></span></li>
                            <div class="form-group">
                                <label><b>Shipping Method</b></label>
                                <?php if($freeShippingEnabled && $freeshippingAble): ?>
                                <div class="custom-control custom-radio mb-1">
                                    <input type="radio" id="customRadioInline1" name="shipping_method" class="shipping-method custom-control-input" value="<?php echo e(Cart::total()); ?>" checked>
                                    <label class="custom-control-label" for="customRadioInline1"><?php echo e(config('settings.free_shipping_label')); ?> </label><span class="float-right">Tk 0.00</span>
                                </div>
                                <?php endif; ?>
                                <?php if($localPicupEnabled): ?>
                                <div class="custom-control custom-radio">
                                    <input type="radio" id="customRadioInline2" name="shipping_method" class="shipping-method custom-control-input" value="<?php echo e(Cart::total() + $localPicupCost); ?>" <?php echo e(!$freeshippingAble ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="customRadioInline2"><?php echo e(config('settings.local_pickup_label')); ?> </label><span class="float-right">Tk <?php echo e($localPicupCost); ?></span>
                                </div>
                                <?php endif; ?>
                                <?php if(!$localPicupEnabled && !$freeShippingEnabled): ?>
                                    <h6 class="text-danger">No shipping method enabled</h6>
                                <?php endif; ?>
                            </div>
                            <li class="sum_total">Total:<span class="cart-total">Tk <?php echo e($cartTotal); ?></span></li>
                        </ul> <a href="<?php echo e(route('checkout')); ?>">Continue to Checkout</a> 
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
<div class="col-xl-12 my-5 py-5">
    <div class="success_message_content text-center">
        <span><i class="icofont-close"></i></span>
        <h3>There are no items in this cart</h3>
        <p>Please add some item in your shopping cart.</p>
        <a href="<?php echo e(route('home')); ?>">Retuen Shop</a>
    </div>
</div>
<?php endif; ?><?php /**PATH F:\laragon\www\ecommerce\resources\views/website/cart/cart-content.blade.php ENDPATH**/ ?>