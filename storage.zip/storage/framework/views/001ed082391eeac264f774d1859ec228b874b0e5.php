<?php $__env->startSection('title', 'Sliders'); ?>
<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <?php $__env->startComponent('layouts.partials.breadcumb'); ?>
        <li class="breadcrumb-item active">Sliders</li>
    <?php echo $__env->renderComponent(); ?>
    
    <!-- end page title end breadcrumb -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="mt-2 header-title float-left">Sliders Information</h4>
                    <a class="btn btn-info btn-sm float-right" href="<?php echo e(route('admin.sliders.create')); ?>"><i class="mdi mdi-plus-circle-outline"></i> Create Slider</a>
                    <button class="btn-delete btn btn-danger btn-sm float-right mr-2" data-url="<?php echo e(route('admin.slider.destroy')); ?>" disabled><i class="mdi mdi-delete"></i> Delete</button>
                </div>
                <div class="card-body">
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Autoplay</th>
                                <th>Autoplay speed</th>
                                <th>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="check-all custom-control-input" id="horizontalCheckbox">
                                        <label class="custom-control-label" for="horizontalCheckbox">Action</label>
                                    </div>
                                </th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(function() {
            $('#datatable').DataTable({
                serverSide: true,
                ajax: "<?php echo e(route('admin.sliders.datatables')); ?>",
                columns: [
                    { name: 'name'},
                    { name: 'autoplay'},
                    { name: 'autoplay_speed'},
                    { name: 'action', orderable: false, searchable: false }
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\ecommerce\resources\views/admin/slider/index.blade.php ENDPATH**/ ?>