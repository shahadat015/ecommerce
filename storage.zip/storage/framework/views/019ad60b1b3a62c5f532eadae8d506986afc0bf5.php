<?php $__env->startPush('css'); ?>
    <link href="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <?php $__env->startComponent('admin::partials.breadcumb'); ?>
        <li class="breadcrumb-item active">Products</li>
    <?php echo $__env->renderComponent(); ?>
    
    <!-- end page title end breadcrumb -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title">Product Stock</h4>
                    <p class="text-muted mb-4 font-13">Available all products.</p>
                    <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Name</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <!-- end col -->
    </div>
    <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $('#datatable').DataTable({
            serverSide: true,
            ajax: "<?php echo e(url('admin/all-products')); ?>",
            columns: [
                { name: 'id' },
                { name: 'name' }
            ],
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin::layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\laragon\www\ecommerce\Modules/Product\Resources/views/admin/list.blade.php ENDPATH**/ ?>