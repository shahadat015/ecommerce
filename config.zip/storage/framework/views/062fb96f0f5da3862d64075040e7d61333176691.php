<!-- satrt breadcome area -->
<section id="bread_come">
    <div class="container">
        <div class="row0">
            <div class="col-xl-12">
                <div class="bread_content">
                    <ul>
                        <li><a href="<?php echo e(route('home')); ?>"><i class="icofont-home"></i> Home </a></li>
                        <?php echo e($slot); ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH F:\laragon\www\ecommerce\resources\views/website/partial/breadcumb.blade.php ENDPATH**/ ?>