<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Admin Dashboard'); ?></title>
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('contents/admin')); ?>/images/favicon.ico">
    <?php echo $__env->yieldPushContent('css'); ?>
    <!-- App css -->
    <link href="<?php echo e(asset('contents/admin')); ?>/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('contents/admin')); ?>/css/icons.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset('contents/admin')); ?>/plugins/pace/pace.min.css">
    <link href="<?php echo e(asset('contents/admin')); ?>/css/metisMenu.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('contents/admin')); ?>/plugins/toast/jquery.toast.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('contents/admin')); ?>/plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('contents/admin')); ?>/css/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    <!-- Top Bar Start -->
    <?php echo $__env->make('layouts.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Top Bar End -->
    <div class="page-wrapper">
        <!-- Left Sidenav -->
        <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end left-sidenav-->
        <!-- Page Content-->
        <div class="page-content">
            <div class="container-fluid">

                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <footer class="footer text-center text-sm-left">&copy; <?php echo config('settings.storefront_copyright_text'); ?> <span class="text-muted d-none d-sm-inline-block float-right">Crafted with <i class="mdi mdi-heart text-danger"></i> by <a href="https://facebook.com/shahadatbd.dev">Shahadat</a></span></footer>
            <!--end footer-->
        </div>
        <!-- end page content -->
    </div>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
    <!-- end page-wrapper -->
    <!-- jQuery  -->
    <script src="<?php echo e(asset('contents/admin')); ?>/js/jquery.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/pace/pace.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/js/metisMenu.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/js/waves.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/js/jquery.slimscroll.min.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/toast/jquery.toast.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/plugins/sweet-alert2/sweetalert2.min.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
    <!-- App js -->
    <script src="<?php echo e(asset('contents/admin')); ?>/js/app.js"></script>
    <script src="<?php echo e(asset('contents/admin')); ?>/js/ajax.js"></script>
</body>

</html><?php /**PATH F:\laragon\www\ecommerce\resources\views/layouts/admin.blade.php ENDPATH**/ ?>