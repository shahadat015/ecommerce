$(function () {
	$('.datepicker').flatpickr({
		autoclose: true,
	});
});