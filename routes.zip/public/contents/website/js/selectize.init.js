$(function () {
	$('.carousel1Products').selectize({
        plugins: ['remove_button']
    });
});