<!-- satrt breadcome area -->
<section id="bread_come">
    <div class="container">
        <div class="row0">
            <div class="col-xl-12">
                <div class="bread_content">
                    <ul>
                        <li><a href="{{ route('home') }}"><i class="icofont-home"></i> Home </a></li>
                        {{$slot}}
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>